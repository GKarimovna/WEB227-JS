let a = prompt("Введите число");
let b = prompt("Введите число");
let c = prompt("Введите число");
let d = prompt("Введите число");
alert (`Сумма квадратов всех чисел = ${a * a + b * b + c * c + d * d}`);
