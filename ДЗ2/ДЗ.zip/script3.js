document.write("<table border = '1' align='center' width = '300' height = '300'>");
for (let i = 1; i < 11; i++) {
    document.write("<tr align='center'>");
    for (let j = 1; j < 11; j++) {
        if(j%2==0 && i%2 || j%2 && i%2==0){
            document.write("<td bgcolor='yellow'>" + i*j + "</td>");
        }
        else {
            document.write("<td bgcolor='red'>" + i*j + "</td>");
        }

    }
    document.write("</tr>");
}
document.write("</table>");

