let h = document.querySelector('.img');
h.addEventListener('click', ch);
function ch(display){
    h.style.display = display.className;
}


