let a = document.querySelector('#cl');
a.addEventListener("click", myMove);

function myMove() {
    let elem = document.getElementById("animate");
    let pos = 0;
    let id = setInterval(frame, 50);
    function frame() {
        if (pos == 350) {
            clearInterval(id);
            a.style.display = "block";
        }
        else {
            pos++;
            elem.style.top = pos + "px";
            elem.style.left = pos + "px";
            a.style.display = "none";
        }
    }
} 